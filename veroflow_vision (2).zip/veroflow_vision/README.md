# VeroFlow — Vision-Based Version

A parallel copy of VeroFlow's core/orchestrator pipeline (v3 engine only —
the legacy /run-test and /run-test-v2 routes were not ported, since your
actual testing only uses v3) rebuilt to work from screenshots instead of
XML dumps.

## Setup

1. Copy `.env.example` to `.env` and fill in `GROQ_API_KEY`.
2. Edit `ADB_PATH` / `AAPT_PATH` at the top of `core/adb_controller.py` to
   match your local SDK install (same values as your XML version).
3. **Verify `VISION_MODEL_NAME` in `core/llm_controller.py`** against
   Groq's current vision-capable model list before running — model names
   and availability change over time; the name shipped here may be stale
   by the time you read this.
4. `pip install -r requirements.txt --break-system-packages` (or in a venv).
5. `uvicorn main:app --reload` from the `backend/` folder.
6. `POST /upload-apk`, then `POST /run-test-v3-vision/{file_id}?description=...`.

## What changed vs. the XML version, file by file

| File | Status |
|---|---|
| `schemas.py` | Rebuilt — `VisualElement` (label/x/y/type/checked/enabled) replaces the XML `Element` |
| `adb_controller.py` | Trimmed — all XML-parsing functions removed; `capture_screenshot()` replaces `dump_ui_hierarchy()` |
| `llm_controller.py` | Rebuilt — every screen-understanding call is now multimodal (sends the actual screenshot) |
| `perception.py` | Rebuilt — `screen_signature`/`evidence_is_grounded` now work from vision-extracted labels, not XML |
| `stability.py` | Adapted — hashes image bytes instead of XML text |
| `state_manager.py` | Same design as the XML version's final state, carried over as-is (this part is model-agnostic) |
| `extractors.py` | **Replaced by `vision_extractors.py`** — best-effort visual state-reading; `CalendarExtractor`'s deterministic day-tap logic has no equivalent (see below) |
| `action_executor.py` | Rebuilt — taps resolve by label lookup or direct coordinates, not resource-id/text XML lookup |
| `decision_router.py` | Ported — same guard chain (dead-end memory, selection groups, completed-milestone guard, risk filtering), adapted to `VisualElement` |
| `navigator.py` | Simplified — just the raw-decision-to-Action conversion |
| `interrupt_handler.py` | Ported, using vision-extracted labels instead of XML text |
| `verifier.py` | Rebuilt — grounding now cross-checks against the elements list a vision call actually extracted |
| `planner.py` | Mostly unchanged — milestone text logic doesn't depend on XML vs. vision |
| `orchestrator.py` | Rebuilt — screenshot loop instead of XML loop; carries the corrected `verify_final` reference point (compares against the screen right before the FINAL action, not the run's very first screen) |
| `main.py` | Single `/run-test-v3-vision/{file_id}` endpoint |

## Known limitations of this version (read before relying on it)

These are structural, not bugs to be patched later — they're the actual
tradeoffs of working from pixels instead of an accessibility tree:

- **Tap precision.** Coordinates are the model's own visual estimate, not
  an exact XML bounds rectangle. Dense UIs (calendar grids, small icon
  rows) are the highest-risk case for mistaps.
- **`checked`/`enabled` state is a visual guess**, not a read attribute.
  A checked box that looks similar to unchecked under some themes can be
  misjudged.
- **`CalendarExtractor`'s deterministic day-tap logic has no port.** The
  XML version located calendar days via a `content-desc="Calendar Day N"`
  convention with no visual equivalent; date selection here is handled
  as an ordinary per-step model decision instead, which is less reliable.
- **`screen_signature` can drift.** It's built from the vision model's
  own label extraction, which isn't guaranteed to read the exact same
  text twice on the physically identical screen. Every piece of "have I
  been here before" memory (dead-end tracking, destination tracking,
  milestone-screen tracking) depends on this being stable, so treat any
  memory-related odd behavior as a first suspect here.
- **Evidence grounding is a cross-check, not ground truth.** It confirms
  a cited label was actually in the extracted elements list, not that
  the extraction itself was correct — unlike the XML version's ability to
  substring-match against the real accessibility tree.
- **Cost/latency.** Every step now sends an image to a vision model
  instead of parsing local text. Expect this to run slower and more
  expensively per step than the XML version.

## Relevance/risk filtering scope note

`find_untried_alternative` here applies the deterministic risk-keyword
filter (Call/Video/Delete/Submit/etc., allowed through only when nothing
else applies) but — to avoid adding a second LLM call type on top of an
already vision-heavy pipeline — does **not** port the XML version's
separate relevance-scoring call. If you find it still tries clearly
irrelevant elements, that's the first thing to add back.
