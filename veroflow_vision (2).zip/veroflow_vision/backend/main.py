import uuid
import shutil
import os
import time

from fastapi import FastAPI, UploadFile, File
from core.llm_controller import understand_goal
from core.adb_controller import (
    get_connected_devices, install_apk, get_package_name,
    launch_app, clear_app_data,
)
from core.orchestrator import run_orchestrated_test

app = FastAPI(title="VeroFlow Backend (Vision)")

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


@app.get("/ping")
def ping():
    return {"status": "ok", "message": "VeroFlow (vision) backend is alive"}


@app.get("/devices")
def devices():
    return {"connected_devices": get_connected_devices()}


@app.post("/upload-apk")
async def upload_apk(file: UploadFile = File(...)):
    file_id = str(uuid.uuid4())
    saved_filename = f"{file_id}.apk"
    saved_path = os.path.join(UPLOAD_DIR, saved_filename)

    with open(saved_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return {"original_filename": file.filename, "saved_as": saved_filename, "file_id": file_id}


@app.post("/run-test-v3-vision/{file_id}")
def run_test_v3_vision(file_id: str, description: str, max_steps: int = 30):
    apk_path = os.path.join(UPLOAD_DIR, f"{file_id}.apk")
    if not os.path.exists(apk_path):
        return {"error": f"No APK found for file_id {file_id}"}

    objective = understand_goal(description)
    goal_summary = objective.get("goal_summary", description)

    package_name = get_package_name(apk_path)
    install_result = install_apk(apk_path)
    clear_app_data(package_name)
    time.sleep(1)
    launch_app(package_name)
    time.sleep(15)

    result = run_orchestrated_test(goal_summary, package_name, max_steps=max_steps)
    result["package_name"] = package_name
    result["install_result"] = install_result
    return result
