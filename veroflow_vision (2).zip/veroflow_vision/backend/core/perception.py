import hashlib
from core.schemas import VisualElement, ScreenState
from core.llm_controller import perceive_screen

# Same two keyword lists as the XML version, and for the same reason kept
# separate: interrupts get auto-dismissed, app errors stop the run. Since
# perceive_screen() already extracts real text labels + a description, we
# can still do this matching cheaply/deterministically — no extra vision
# call needed for this check.
INTERRUPT_HINTS = [
    "allow", "deny", "while using the app", "only this time",
    "update available", "no thanks", "not now", "app has stopped",
    "keep app open", "close app", "turn on location", "grant permission"
]

ERROR_HINTS = [
    "error", "failed", "declined", "invalid", "something went wrong",
    "please try again", "unable to", "incorrect", "required field",
    "please fill", "please enter", "transaction failed", "payment failed"
]


def build_screen_state(screenshot_path: str) -> ScreenState:
    """
    The vision equivalent of the XML version's build_screen_state — the
    ONLY function that calls perceive_screen(), so every consumer works
    from one consistent snapshot per screenshot.
    """
    result = perceive_screen(screenshot_path)
    elements = [
        VisualElement(
            label=e.get("label", ""),
            x=e.get("x", 0),
            y=e.get("y", 0),
            element_type=e.get("element_type", "button"),
            checked=e.get("checked"),
            enabled=e.get("enabled", True),
        )
        for e in result.get("elements", [])
        if e.get("label")
    ]

    from PIL import Image
    with Image.open(screenshot_path) as img:
        width, height = img.size

    return ScreenState(
        screenshot_path=screenshot_path,
        screen_width=width,
        screen_height=height,
        elements=elements,
        screen_description=result.get("screen_description", ""),
    )


def _combined_text(screen_state: ScreenState) -> str:
    parts = [screen_state.screen_description] + [el.label for el in screen_state.elements]
    return " ".join(parts).lower()


def detect_interrupt(screen_state: ScreenState) -> bool:
    return any(hint in _combined_text(screen_state) for hint in INTERRUPT_HINTS)


def detect_app_error(screen_state: ScreenState) -> str | None:
    combined = _combined_text(screen_state)
    for hint in ERROR_HINTS:
        if hint in combined:
            return hint
    return None


def screen_signature(screen_state: ScreenState) -> str:
    """
    Vision equivalent of the XML version's element-identity signature.
    Built from each element's (label, element_type) only — deliberately
    excludes x/y (coordinates can jitter slightly between vision calls
    on the visually-identical screen) and 'checked' (so making a
    selection doesn't change the screen's identity, same intent as the
    XML version). This is the closest achievable analog, but is
    inherently a bit less stable than the XML version's signature,
    since it depends on the vision model re-reading labels consistently
    across repeated calls on the same physical screen.
    """
    parts = sorted(f"{el.label}|{el.element_type}" for el in screen_state.elements)
    combined = "||".join(parts)
    return hashlib.md5(combined.encode("utf-8")).hexdigest()


def evidence_is_grounded(evidence_list: list, screen_state: ScreenState, milestone_text: str = "") -> bool:
    """
    Vision-appropriate grounding: since there's no XML to substring-match
    against, "grounded" here means the cited label must be an EXACT match
    (case-insensitive) to a real label perceive_screen actually extracted
    for THIS screen — cross-checking the decision call's citation against
    the perception call's own extraction, rather than an independent
    ground truth (that independent truth doesn't exist for images the
    way it does for XML). This is weaker than the XML version's grounding
    but is the closest available check.
    """
    if not evidence_list:
        return False

    labels_lower = {el.label.strip().lower(): el for el in screen_state.elements}

    _GENERIC_UI_LABELS = {
        "skip", "next", "back", "continue", "ok", "cancel", "close", "done",
        "submit", "login", "register", "sign in", "sign up", "welcome",
        "welcome back", "home", "menu", "search",
    }
    milestone_words = set(w for w in milestone_text.lower().split() if len(w) > 2) if milestone_text else set()

    for item in evidence_list:
        ev_type = item.get("type", "text")
        value = (item.get("value") or "").strip()
        if not value:
            return False
        value_lower = value.lower()

        matched_el = labels_lower.get(value_lower)
        if matched_el is None:
            return False

        if ev_type == "selection":
            if matched_el.checked is not True:
                return False

        if milestone_words and value_lower in _GENERIC_UI_LABELS:
            evidence_words = set(w for w in value_lower.split() if len(w) > 2)
            if evidence_words and not (evidence_words & milestone_words):
                return False

    return True
