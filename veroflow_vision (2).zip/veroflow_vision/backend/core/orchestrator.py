import os
import re
import time
import shutil

from core.schemas import StepEvent, Action, VerificationResult
from core.state_manager import TestRunState
from core.perception import build_screen_state, detect_app_error, screen_signature, evidence_is_grounded
from core.interrupt_handler import resolve_interrupt
from core.decision_router import decide, find_untried_alternative
from core.llm_controller import evaluate_and_decide
from core.navigator import build_action_from_raw
from core.action_executor import execute_action
from core.verifier import verify_now, verify_final, _elements_as_dicts
from core.vision_extractors import resolve_checkbox
from core.adb_controller import tap, press_back, get_foreground_package, launch_app, scroll_down, capture_screenshot
from core.stability import wait_for_stable_screen
from core.planner import build_milestones

UPLOAD_DIR = "uploads"

_TIME_PATTERN = re.compile(r"\d{1,2}:\d{2}\s*(AM|PM)", re.IGNORECASE)
_FORWARD_CTA_KEYWORDS = ["book now", "continue", "next", "confirm", "proceed", "reserve", "select", "pay", "checkout"]


class _ScreenStore:
    """
    Every screenshot taken during a run is saved under its own unique
    filename inside a per-run folder. This matters: ScreenState only
    holds a file PATH, so if every capture overwrote one shared file,
    an earlier ScreenState (e.g. the "before" screen used by
    verify_final) would silently point at a newer screenshot. Also
    leaves you a full visual record of the run to inspect afterwards.
    """

    def __init__(self):
        self.dir = os.path.join(UPLOAD_DIR, "run_screens", time.strftime("%Y%m%d_%H%M%S"))
        os.makedirs(self.dir, exist_ok=True)
        self._n = 0

    def persist(self, src_path: str) -> str:
        self._n += 1
        dest = os.path.join(self.dir, f"screen_{self._n:04d}.png")
        shutil.copyfile(src_path, dest)
        return dest

    def capture(self) -> str:
        src = capture_screenshot(os.path.join(UPLOAD_DIR, "window_screen.png"))
        return self.persist(src)


def _event_to_history_dict(event: StepEvent) -> dict:
    action = event.action_taken
    verification = event.verification
    result = {
        "step": event.step_number,
        "action": action.type if action else None,
        "label": action.label if action else None,
        "value": action.value if action else None,
        "reason": action.reason if action else None,
        "success_checked": verification.success if verification else None,
        "error": event.error,
    }
    if event.widget_result:
        result["widget_already_satisfied"] = event.widget_result.get("already_satisfied", False)
        result["widget_verified"] = event.widget_result.get("verified", False)
    if event.milestone_debug:
        result["milestone_debug"] = event.milestone_debug
    return result


def _record_click_destination(origin_sig: str, action: Action, state: TestRunState, after_state):
    if action.type != "tap" or not action.label:
        return
    state.record_action_destination(origin_sig, action.label, screen_signature(after_state))


def _find_forward_cta(screen_state, keywords=None):
    keywords = keywords or _FORWARD_CTA_KEYWORDS
    for el in screen_state.elements:
        if not el.enabled:
            continue
        if any(kw in el.label.strip().lower() for kw in keywords):
            return el
    return None


def _screen_has_time_text(screen_state) -> bool:
    if _TIME_PATTERN.search(screen_state.screen_description or ""):
        return True
    return any(_TIME_PATTERN.search(el.label or "") for el in screen_state.elements)


def _scroll(screen_state):
    scroll_down(screen_state.screen_width, screen_state.screen_height)


def run_orchestrated_test(goal_summary: str, package_name: str, max_steps: int = 20) -> dict:
    store = _ScreenStore()
    state = TestRunState(goal_summary=goal_summary, max_steps=max_steps)
    state.set_milestones(build_milestones(goal_summary))

    initial_screen = build_screen_state(store.capture())
    # The screen right before the LAST action taken — this (not the very
    # first screen of the run) is what verify_final compares against.
    last_pre_action_screen = initial_screen
    # After a dispatched action we already capture + perceive the
    # resulting screen; reuse it as the next iteration's starting state
    # instead of paying for a second identical capture + vision call.
    carried_state = initial_screen

    while not state.budget_exceeded():
        if carried_state is not None:
            screen_state, carried_state = carried_state, None
        else:
            screen_state = build_screen_state(store.capture())
        current_signature = screen_signature(screen_state)
        state.record_screen_depth(current_signature)
        state.record_screen_signature(current_signature)

        if state.milestone_exhausted():
            state.record_event(StepEvent(
                step_number=state.current_step,
                screen_before=screen_state,
                action_taken=None,
                verification=None,
                error=f"Milestone '{state.current_milestone()}' could not be completed after exhausting visible options — stopping run.",
                milestone_debug=state.last_milestone_debug,
            ))
            break

        error_hint = detect_app_error(screen_state)
        if error_hint:
            state.record_event(StepEvent(
                step_number=state.current_step,
                screen_before=screen_state,
                action_taken=None,
                verification=None,
                error=f"App-level error/validation message detected on screen (matched: '{error_hint}'). Stopping run.",
                milestone_debug=state.last_milestone_debug,
            ))
            break

        # 1. Interrupt handling. A deterministic match is executed right
        # away. If a dialog is detected but nothing matches, we DON'T stop
        # the run (the XML version did, contradicting its own docstring) —
        # we fall through so the normal decision step, which can see the
        # dialog's buttons, handles it.
        is_interrupt, interrupt_action = resolve_interrupt(screen_state)
        if is_interrupt and interrupt_action is not None:
            last_pre_action_screen = screen_state
            result = execute_action(interrupt_action, screen_state)
            state.record_event(StepEvent(
                step_number=state.current_step,
                screen_before=screen_state,
                action_taken=interrupt_action,
                verification=None,
                error=None if result.success else result.error,
                milestone_debug=state.last_milestone_debug,
            ))
            wait_for_stable_screen(max_wait_seconds=4.0)
            continue

        # 2. Milestone check + next-action decision in ONE call. If the
        # model's own next step is just "scroll down" (nothing usable
        # visible yet), scroll once for real and look again — one step at
        # a time, never scrolling back, so whatever we decide to tap is
        # always on the screen we actually just looked at. Bottom of the
        # page is detected when a scroll leaves the screen signature
        # unchanged.
        current_milestone_full = state.current_milestone()
        current_milestone_text = current_milestone_full.lower()
        combined = None
        scroll_attempts = 0
        while True:
            combined = evaluate_and_decide(
                screen_state.screenshot_path,
                _elements_as_dicts(screen_state),
                current_milestone_full,
                goal_summary,
                [_event_to_history_dict(e) for e in state.events[-3:]],
                known_unproductive=state.known_unproductive_labels_for_screen(current_signature),
            )
            if not isinstance(combined.get("next_action"), dict):
                combined["next_action"] = {"action": "wait", "value": 2, "reason": "Model returned no usable next_action"}
            wants_scroll = combined["next_action"].get("action") == "scroll_down"
            if not (wants_scroll and scroll_attempts < 4):
                break
            previous_signature = current_signature
            _scroll(screen_state)
            scroll_attempts += 1
            screen_state = build_screen_state(store.persist(wait_for_stable_screen(max_wait_seconds=4.0)))
            current_signature = screen_signature(screen_state)
            if current_signature == previous_signature:
                break  # scrolling revealed nothing new — bottom reached

        evidence = combined.get("milestone_evidence", [])
        if not isinstance(evidence, list):
            evidence = []
        milestone_result = {
            "reached": bool(combined.get("milestone_reached", False)),
            "reason": combined.get("milestone_reason", ""),
            "evidence": [e for e in evidence if isinstance(e, dict)],
        }
        precomputed_action = build_action_from_raw(combined["next_action"])

        # Deterministic backstop for compound date+time milestones (carried
        # over from the XML version): claiming both requires some
        # time-formatted text to actually be visible.
        if milestone_result["reached"] and "date" in current_milestone_text and "time" in current_milestone_text:
            if not _screen_has_time_text(screen_state):
                milestone_result["reached"] = False
                milestone_result["reason"] = "Deterministic override: milestone requires both date AND time, but no time-formatted text was detected on screen"
                milestone_result["evidence"] = []

        milestone_advanced = False
        if milestone_result["reached"]:
            evidence_list = milestone_result["evidence"]
            grounded = evidence_is_grounded(evidence_list, screen_state, milestone_text=current_milestone_full)
            evidence_key = "||".join(sorted(
                f"{e.get('type', 'text')}:{(e.get('value') or '').strip().lower()}" for e in evidence_list
            ))
            not_reused = grounded and evidence_key and not state.evidence_already_used(evidence_key)

            if not_reused:
                state.mark_current_milestone_screens_completed()
                state.advance_milestone()
                state.recent_screen_signatures.clear()
                state.mark_evidence_used(evidence_key)
                state.reset_milestone_check_failures()
                milestone_advanced = True
            else:
                state.record_milestone_check_failure(current_signature)
        else:
            state.record_milestone_check_failure(current_signature)

        skipped_due_to_exhaustion = False
        if not milestone_advanced and state.milestone_unreachable():
            state.skip_current_milestone()
            milestone_advanced = True
            skipped_due_to_exhaustion = True

        state.last_milestone_debug = {
            "milestone_checked": current_milestone_full if not milestone_advanced else (
                "(skipped - unreachable)" if skipped_due_to_exhaustion else "(just advanced - genuine)"
            ),
            "llm_said_reached": milestone_result["reached"],
            "llm_reason": milestone_result["reason"],
            "llm_evidence": milestone_result["evidence"],
            "grounding_passed": evidence_is_grounded(milestone_result["evidence"], screen_state, milestone_text=current_milestone_full) if milestone_result["reached"] else None,
        }

        # 3. Dead-end detection: screen unchanged for 2 checks in a row.
        if state.screen_signature_is_static(lookback=2):
            origin_sig, clicked_label = state.last_screen_before_action or (current_signature, "")
            last_action_type_here = state.events[-1].action_taken.type if state.events and state.events[-1].action_taken else "unknown"
            state.mark_dead_end(current_signature, f"__action_type__:{last_action_type_here}")
            state.record_milestone_dead_end()
            if clicked_label:
                state.mark_dead_end(origin_sig, clicked_label)

            # Try an untried option right here BEFORE backing out — going
            # back can exit the app entirely on a first-launch screen.
            alternative_action = find_untried_alternative(screen_state, state)
            if alternative_action is not None:
                last_pre_action_screen = screen_state
                alt_result = execute_action(alternative_action, screen_state)
                alt_after_state = build_screen_state(store.persist(wait_for_stable_screen(max_wait_seconds=4.0)))
                _record_click_destination(current_signature, alternative_action, state, alt_after_state)
                state.record_event(StepEvent(
                    step_number=state.current_step,
                    screen_before=screen_state,
                    action_taken=alternative_action,
                    verification=None,
                    error=None if alt_result.success else alt_result.error,
                    milestone_debug=state.last_milestone_debug,
                ))
                carried_state = alt_after_state
                continue

            last_pre_action_screen = screen_state
            pre_back_signature = current_signature
            exited_app = False
            for _ in range(3):
                press_back()
                post_back_path = store.persist(wait_for_stable_screen())
                current_package = get_foreground_package()
                if package_name and current_package and current_package != package_name:
                    exited_app = True
                    break
                post_back_signature = screen_signature(build_screen_state(post_back_path))
                if post_back_signature != pre_back_signature:
                    break
                pre_back_signature = post_back_signature

            if exited_app:
                launch_app(package_name)
                wait_for_stable_screen()

            dead_end_action = Action(
                type="tap" if clicked_label else "scroll_down",
                label=clicked_label or None,
                reason=f"Dead-end recovery: screen stopped changing after repeated '{last_action_type_here}', backed out and marked this screen+action as unproductive",
                source="deterministic",
            )
            dead_end_action.failure_reason = "dead_end_no_new_options"
            state.record_event(StepEvent(
                step_number=state.current_step,
                screen_before=screen_state,
                action_taken=dead_end_action,
                verification=None,
                error=None,
                milestone_debug=state.last_milestone_debug,
            ))
            state.recent_screen_signatures.clear()
            continue

        # 4. Stall detection: the same action repeated with no progress.
        if state.is_repeating():
            last_action_type = state.events[-1].action_taken.type if state.events[-1].action_taken else None
            last_pre_action_screen = screen_state
            if last_action_type in ("scroll_down", "scroll_up"):
                cta_element = _find_forward_cta(screen_state)
                if cta_element is not None:
                    stall_action = Action(type="tap", label=cta_element.label,
                                          reason="Stall recovery: scrolling found nothing new, tapping likely CTA button",
                                          source="deterministic")
                    execute_action(stall_action, screen_state)
                else:
                    stall_action = Action(type="scroll_down", reason="Stall recovery fallback: no CTA found, scrolling anyway", source="deterministic")
                    _scroll(screen_state)
            else:
                stall_action = Action(type="scroll_down", reason="Stall recovery: repeated non-scroll action detected", source="deterministic")
                _scroll(screen_state)

            wait_for_stable_screen(max_wait_seconds=4.0)
            state.record_event(StepEvent(
                step_number=state.current_step,
                screen_before=screen_state,
                action_taken=stall_action,
                verification=None,
                error=None,
                milestone_debug=state.last_milestone_debug,
            ))
            continue

        # 5. Decision router (deterministic guard chain over the model's proposal).
        action = decide(screen_state, goal_summary,
                        [_event_to_history_dict(e) for e in state.events[-3:]],
                        state=state,
                        precomputed_action=precomputed_action)

        if action.type == "done":
            state.finished = True
            break

        # Redundancy guard: a checkbox already handled earlier this run
        # shouldn't be re-set — progress via the forward button instead.
        if action.type == "set_checkbox":
            widget_key = action.label or "checkbox"
            if state.is_widget_complete("set_checkbox", widget_key):
                cta_element = _find_forward_cta(screen_state)
                if cta_element is not None:
                    redirect_action = Action(type="tap", label=cta_element.label,
                                             reason=f"Redundancy guard: '{widget_key}' already completed, progressing via CTA instead of repeating",
                                             source="deterministic")
                    last_pre_action_screen = screen_state
                    result = execute_action(redirect_action, screen_state)
                    state.record_event(StepEvent(
                        step_number=state.current_step,
                        screen_before=screen_state,
                        action_taken=redirect_action,
                        verification=None,
                        error=None if result.success else result.error,
                        blocked_duplicate=True,
                        milestone_debug=state.last_milestone_debug,
                    ))
                else:
                    state.record_event(StepEvent(
                        step_number=state.current_step,
                        screen_before=screen_state,
                        action_taken=action,
                        verification=None,
                        error=None,
                        blocked_duplicate=True,
                        widget_result={"already_satisfied": True, "verified": True},
                        milestone_debug=state.last_milestone_debug,
                    ))
                wait_for_stable_screen()
                continue

        # 6. Dispatch.
        error = None
        widget_result_for_event = None
        last_pre_action_screen = screen_state

        if action.type == "set_checkbox":
            target = True if action.target_value is None else bool(action.target_value)
            widget_result = resolve_checkbox(screen_state, action.label or "", target, tap, store.capture, build_screen_state)
            widget_result_for_event = widget_result
            if not widget_result.get("matched"):
                # The model called it a checkbox but we couldn't find one —
                # retry the same target as a plain tap before giving up.
                fallback_action = Action(type="tap", label=action.label,
                                         reason=f"Fallback: '{action.label}' did not resolve as a checkbox, retrying as a plain tap",
                                         source="deterministic")
                fallback_result = execute_action(fallback_action, screen_state)
                action = fallback_action
                widget_result_for_event = None
                error = None if fallback_result.success else fallback_result.error
            elif widget_result.get("verified") or widget_result.get("already_satisfied"):
                state.mark_widget_complete("set_checkbox", action.label or "checkbox")
        elif action.type == "wait":
            try:
                time.sleep(float(action.value or 2))
            except (TypeError, ValueError):
                time.sleep(2)
        else:
            core_id = action.label
            is_core = any(w in (action.reason or "").lower() for w in ["add", "submit", "confirm", "buy", "pay", "checkout"])
            if is_core and core_id and state.is_core_action_done(core_id):
                state.record_event(StepEvent(
                    step_number=state.current_step,
                    screen_before=screen_state,
                    action_taken=action,
                    verification=None,
                    blocked_duplicate=True,
                    milestone_debug=state.last_milestone_debug,
                ))
                continue

            if action.type == "tap":
                state.last_screen_before_action = (current_signature, action.label or "")

            result = execute_action(action, screen_state)
            error = None if result.success else result.error
            if is_core and core_id and result.success:
                state.mark_core_action(core_id)

        # 7. Observe the result once, reuse it for verification, memory
        # and as the next iteration's starting screen.
        after_state = build_screen_state(store.persist(wait_for_stable_screen()))
        after_signature = screen_signature(after_state)
        changed = after_signature != current_signature
        state.record_action_outcome(current_signature, action, changed, error)
        _record_click_destination(current_signature, action, state, after_state)

        if changed:
            verification = state.get_cached_verification(after_signature)
            if verification is None:
                verification = verify_now(after_state, goal_summary)
                state.cache_verification(after_signature, verification)
        else:
            verification = VerificationResult(False, "No change detected after action", "before_after_diff")

        state.record_event(StepEvent(
            step_number=state.current_step,
            screen_before=screen_state,
            action_taken=action,
            verification=verification,
            error=error,
            widget_result=widget_result_for_event,
            milestone_debug=state.last_milestone_debug,
        ))
        carried_state = after_state

        if verification.success:
            state.finished = True
            break

    final_screen = build_screen_state(store.capture())
    final_verification = verify_final(last_pre_action_screen, final_screen, goal_summary)

    return {
        "goal_summary": goal_summary,
        "milestones": state.milestones,
        "current_milestone_index": state.current_milestone_index,
        "finished": state.finished,
        "steps_taken": state.current_step,
        "events": [_event_to_history_dict(e) for e in state.events],
        "final_verification": final_verification.__dict__,
        "screenshots_dir": store.dir,
    }
