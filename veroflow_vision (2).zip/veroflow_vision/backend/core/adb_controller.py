import subprocess
import base64

# NOTE: update these to match your local SDK install, same as the XML version.
ADB_PATH = r"F:\MyAndriod\SDK\platform-tools\adb.exe"
AAPT_PATH = r"F:\MyAndriod\SDK\build-tools\37.0.0\aapt.exe"


def run_adb_command(args: list[str]) -> str:
    result = subprocess.run(
        [ADB_PATH] + args,
        capture_output=True,
        text=True
    )
    return result.stdout.strip()


def get_connected_devices() -> list[str]:
    output = run_adb_command(["devices"])
    lines = output.splitlines()[1:]
    devices = []
    for line in lines:
        if line.strip() and "device" in line:
            devices.append(line.split()[0])
    return devices


def capture_screenshot(local_save_path: str) -> str:
    """
    Replaces dump_ui_hierarchy() from the XML version. Captures the
    current screen as a PNG on the device, pulls it to local_save_path,
    and returns that path. This is the ONLY "look at the screen" call
    in the vision pipeline — there is no XML dump anywhere.
    """
    device_path = "/sdcard/veroflow_screen.png"
    run_adb_command(["shell", "screencap", "-p", device_path])
    run_adb_command(["pull", device_path, local_save_path])
    return local_save_path


def install_apk(apk_path: str) -> str:
    return run_adb_command(["install", "-r", apk_path])


def get_package_name(apk_path: str) -> str:
    result = subprocess.run(
        [AAPT_PATH, "dump", "badging", apk_path],
        capture_output=True,
        text=True
    )
    for line in result.stdout.splitlines():
        if line.startswith("package:"):
            start = line.find("name='") + len("name='")
            end = line.find("'", start)
            return line[start:end]
    return ""


def launch_app(package_name: str) -> str:
    return run_adb_command([
        "shell", "monkey", "-p", package_name,
        "-c", "android.intent.category.LAUNCHER", "1"
    ])


def force_stop_app(package_name: str) -> str:
    return run_adb_command(["shell", "am", "force-stop", package_name])


def clear_app_data(package_name: str) -> str:
    """Full reset to a fresh-install state, same as the XML version."""
    return run_adb_command(["shell", "pm", "clear", package_name])


def tap(x: int, y: int) -> str:
    return run_adb_command(["shell", "input", "tap", str(x), str(y)])


def type_text(text: str) -> str:
    """
    Sends text via ADBKeyboard's base64 broadcast — identical mechanism
    to the XML version. The device must have ADBKeyboard installed and
    set as the active input method.
    """
    encoded = base64.b64encode(text.encode("utf-8")).decode("utf-8")
    return run_adb_command(["shell", "am", "broadcast", "-a", "ADB_INPUT_B64", "--es", "msg", encoded])


def clear_text_field() -> str:
    return run_adb_command(["shell", "am", "broadcast", "-a", "ADB_CLEAR_TEXT"])


def clear_field(x: int, y: int) -> None:
    tap(x, y)
    clear_text_field()


def swipe(x1: int, y1: int, x2: int, y2: int, duration_ms: int = 300) -> str:
    return run_adb_command(["shell", "input", "swipe", str(x1), str(y1), str(x2), str(y2), str(duration_ms)])


def scroll_down(screen_width: int = 1440, screen_height: int = 2392) -> str:
    x = screen_width // 2
    y1 = int(screen_height * 0.7)
    y2 = int(screen_height * 0.3)
    return swipe(x, y1, x, y2, 400)


def scroll_up(screen_width: int = 1440, screen_height: int = 2392) -> str:
    x = screen_width // 2
    y1 = int(screen_height * 0.3)
    y2 = int(screen_height * 0.7)
    return swipe(x, y1, x, y2, 400)


def long_press(x: int, y: int, duration_ms: int = 800) -> str:
    return swipe(x, y, x, y, duration_ms)


def get_screen_size() -> tuple:
    output = run_adb_command(["shell", "wm", "size"])
    for line in output.splitlines():
        if "Physical size" in line or "Override size" in line:
            dims = line.split(":")[-1].strip()
            w, h = dims.split("x")
            return (int(w), int(h))
    return (1440, 2392)


def press_back() -> str:
    return run_adb_command(["shell", "input", "keyevent", "4"])


def get_foreground_package() -> str:
    output = run_adb_command(["shell", "dumpsys", "window", "windows"])
    for line in output.splitlines():
        if "mCurrentFocus" in line and "/" in line:
            try:
                segment = line.split("{")[1].split("}")[0]
                app_part = segment.split(" ")[-1]
                return app_part.split("/")[0]
            except (IndexError, ValueError):
                continue
    return ""
