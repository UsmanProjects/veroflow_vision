import time
import hashlib
from core.adb_controller import capture_screenshot

UPLOAD_DIR = "uploads"


def _dump():
    import os
    return capture_screenshot(os.path.join(UPLOAD_DIR, "window_screen.png"))


def _signature(screenshot_path: str) -> str:
    """
    Cheap fingerprint of screen content — hashes the raw PNG bytes.
    NOTE: this is STRICTER than the vision-based screen_signature() in
    perception.py (which hashes extracted labels, ignoring cosmetic
    noise). A raw byte hash changes on ANY pixel difference — a blinking
    cursor, a subtle animation frame, or a live clock — so a screen that
    is functionally done loading may still take the full timeout to
    register as "stable" here. If this causes false-timeout waits in
    practice, consider swapping to a perceptual hash (e.g. the
    `imagehash` package) instead of a raw byte hash.
    """
    with open(screenshot_path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def wait_for_stable_screen(
    max_wait_seconds: float = 6.0,
    poll_interval: float = 0.5,
    stable_polls_required: int = 2,
) -> str:
    """
    Polls the screen repeatedly until its image signature stops changing
    for `stable_polls_required` consecutive polls, or max_wait_seconds is
    reached. Returns the final screenshot path.
    """
    start = time.time()
    last_signature = None
    stable_count = 0

    while time.time() - start < max_wait_seconds:
        path = _dump()
        sig = _signature(path)

        if sig == last_signature:
            stable_count += 1
            if stable_count >= stable_polls_required:
                return path
        else:
            stable_count = 0

        last_signature = sig
        time.sleep(poll_interval)

    return _dump()
