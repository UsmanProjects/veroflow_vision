import re
import hashlib
from core.schemas import Action, ScreenState

CONTINUE_KEYWORDS = ["continue", "confirm", "proceed", "next", "submit", "pay", "checkout"]
BACKWARD_KEYWORDS = ["edit", "back", "change", "modify"]
FORWARD_KEYWORDS = ["confirm", "continue", "pay", "submit", "book", "next", "proceed"]
COMPLETED_MILESTONE_CTA_KEYWORDS = ["continue", "confirm", "next", "proceed", "book now", "pay", "checkout", "book", "done", "submit"]
RISKY_ACTION_KEYWORDS = [
    "call", "video", "delete", "remove", "cancel", "submit", "purchase",
    "buy", "pay", "send", "confirm", "start exam", "logout", "log out",
    "sign out", "uninstall", "block", "report",
]


def _is_risky_label(label: str) -> bool:
    label_lower = (label or "").strip().lower()
    return any(kw in label_lower for kw in RISKY_ACTION_KEYWORDS)


def _has_unchecked_prerequisite(screen_state: ScreenState, state=None):
    """
    Simpler than the XML version here: VisualElement.checked is already a
    direct field from the vision model (no XML sibling-node hunting
    needed). Still keeps the same y-proximity "already-satisfied group"
    distinction — a lone required checkbox vs. one option in an
    already-satisfied radio-style group.
    """
    checkable_candidates = [el for el in screen_state.elements if el.checked is not None and el.enabled]

    for el in checkable_candidates:
        if el.checked:
            continue
        # A member of a single-choice group (time slots, calendar days)
        # that already has a recorded pick is settled — never a
        # "required checkbox", however far it sits from the chosen one.
        if _is_sibling_of_decided_group(el, screen_state, state):
            continue

        has_checked_sibling = any(
            other is not el
            and other.checked is not None
            and other.checked
            and abs(other.y - el.y) < 60
            for other in screen_state.elements
        )
        if has_checked_sibling:
            continue

        return el

    return None


def enforce_prerequisites(action: Action, screen_state: ScreenState, state=None) -> Action:
    if action.type not in ("tap",):
        return action

    label = (action.label or "").lower()
    if not any(kw in label for kw in CONTINUE_KEYWORDS):
        return action

    unchecked = _has_unchecked_prerequisite(screen_state, state)
    if unchecked is None:
        return action

    return Action(
        type="set_checkbox",
        label=unchecked.label,
        target_value=True,
        reason=f"Prerequisite guard: redirected from '{action.label}' because an unchecked checkbox ('{unchecked.label}') is still present on screen",
        source="deterministic",
    )


def _matches_selection_group_pattern(label: str) -> bool:
    label = (label or "").strip()
    if not label:
        return False
    if re.match(r'^\d{1,2}(:\d{2})?\s*(AM|PM)?$', label):
        return True
    if label.isdigit() and len(label) <= 2:
        return True
    return False


def _detect_selection_group(screen_state: ScreenState):
    time_like = [el for el in screen_state.elements if re.match(r'^\d{1,2}(:\d{2})?\s*(AM|PM)?$', el.label.strip())]
    day_like = [el for el in screen_state.elements if el.label.strip().isdigit() and len(el.label.strip()) <= 2]

    if len(time_like) >= 3:
        members = sorted(set(el.label.strip() for el in time_like))
        stable_key = hashlib.md5("|".join(members).encode("utf-8")).hexdigest()
        return "time_slot_picker", stable_key
    if len(day_like) >= 5:
        members = sorted(set(el.label.strip() for el in day_like))
        stable_key = hashlib.md5("|".join(members).encode("utf-8")).hexdigest()
        return "calendar_day_picker", stable_key
    return None


def _is_sibling_of_decided_group(el, screen_state: ScreenState, state) -> bool:
    if state is None:
        return False
    if not _matches_selection_group_pattern(el.label):
        return False
    group_result = _detect_selection_group(screen_state)
    if not group_result:
        return False
    group_hint, stable_key = group_result
    existing = state.get_existing_selection(stable_key, group_hint)
    return bool(existing)


def avoid_known_dead_ends(action: Action, screen_state: ScreenState, state) -> Action:
    if action.type != "tap":
        return action
    from core.perception import screen_signature
    origin_sig = screen_signature(screen_state)
    label = action.label or ""
    if label and state.is_known_dead_end(origin_sig, label):
        return Action(type="scroll_down", reason=f"Avoided known dead end: '{label}' from this screen already failed earlier this run", source="deterministic")
    return action


def avoid_already_failed_actions(action: Action, screen_state: ScreenState, state) -> Action:
    if action.type not in ("tap", "set_checkbox"):
        return action
    from core.perception import screen_signature
    sig = screen_signature(screen_state)
    if state.action_already_failed(sig, action):
        return Action(type="scroll_down", reason=f"Avoided repeating already-failed action: '{action.label}'", source="deterministic")
    return action


def enforce_regression_justification(action: Action, screen_state: ScreenState, state) -> Action:
    if action.type != "tap":
        return action
    label = (action.label or "").lower()
    if not any(kw in label for kw in BACKWARD_KEYWORDS):
        return action

    from core.perception import screen_signature
    sig = screen_signature(screen_state)

    has_disabled_primary = any(
        (not el.enabled) and any(kw in el.label.lower() for kw in FORWARD_KEYWORDS)
        for el in screen_state.elements
    )

    fixable_prerequisite = _has_unchecked_prerequisite(screen_state, state) if has_disabled_primary else None
    if fixable_prerequisite is not None:
        return Action(
            type="set_checkbox",
            label=fixable_prerequisite.label,
            target_value=True,
            reason=f"Regression guard: blocked backward action '{action.label}' — a fixable unchecked prerequisite explains the disabled forward button",
            source="deterministic",
        )

    forward_already_failed = state.screen_has_recorded_failure(sig)
    if has_disabled_primary:
        action.failure_reason = "required_element_disabled"
        return action
    if forward_already_failed:
        action.failure_reason = "current_option_unavailable"
        return action

    forward_element = None
    for el in screen_state.elements:
        if el.enabled and any(kw in el.label.lower() for kw in FORWARD_KEYWORDS):
            forward_element = el
            break
    if forward_element:
        return Action(
            type="tap",
            label=forward_element.label,
            reason=f"Regression guard: blocked unjustified backward action '{action.label}', trying '{forward_element.label}' instead",
            source="deterministic",
        )
    return action


def avoid_redoing_completed_milestone(action: Action, screen_state: ScreenState, state) -> Action:
    """
    Only guards plain taps — set_checkbox/set_counter are deliberately
    left alone, since enforce_prerequisites (which runs earlier) is
    specifically responsible for producing those when a real prerequisite
    (like an unchecked policy checkbox) genuinely still needs handling on
    this same screen, and that correct decision must never be overridden
    here. (This exact bug was found and fixed in the XML version.)
    """
    if action.type != "tap":
        return action

    from core.perception import screen_signature
    sig = screen_signature(screen_state)

    if not state.is_completed_milestone_screen(sig):
        return action

    cta_element = None
    for el in screen_state.elements:
        if not el.enabled:
            continue
        label = el.label.strip().lower()
        if any(kw in label for kw in COMPLETED_MILESTONE_CTA_KEYWORDS):
            cta_element = el
            break

    if cta_element is not None:
        return Action(
            type="tap",
            label=cta_element.label,
            reason="Completed-milestone guard: this screen's requirement was already satisfied earlier this run — progressing via forward control instead of repeating it",
            source="deterministic",
        )

    return Action(type="scroll_down", reason="Completed-milestone guard: no forward control visible yet, scrolling to look for one", source="deterministic")


def avoid_reentering_unhelpful_destination(action: Action, screen_state: ScreenState, state) -> Action:
    if action.type != "tap":
        return action
    from core.perception import screen_signature
    sig = screen_signature(screen_state)
    label = action.label or ""
    if not label:
        return action
    destination = state.get_action_destination(sig, label)
    if destination and state.is_unhelpful_milestone_screen(destination):
        return Action(type="scroll_down", reason=f"Avoided '{label}': already know it leads to an already-explored, unhelpful screen for this milestone", source="deterministic")
    return action


def find_untried_alternative(screen_state: ScreenState, state):
    """
    Tries an untried, non-risky (or risky-but-clearly-relevant) element
    on THIS screen before backtracking. Simpler than the XML version's
    relevance-scoring call — this version applies only the deterministic
    risk-keyword filter, skipping the extra LLM relevance call to keep
    step count/cost down in this first vision implementation.
    """
    from core.perception import screen_signature
    sig = screen_signature(screen_state)

    candidates = [el for el in screen_state.elements if el.enabled and el.label]

    for el in candidates:
        label = el.label.strip()
        if not label:
            continue
        if state.is_known_dead_end(sig, label):
            continue
        if _is_sibling_of_decided_group(el, screen_state, state):
            continue

        probe_action = Action(type="tap", label=label, source="deterministic")
        if state.action_already_failed(sig, probe_action):
            continue

        known_destination = state.get_action_destination(sig, label)
        if known_destination and state.is_unhelpful_milestone_screen(known_destination):
            continue

        if _is_risky_label(label):
            continue

        return Action(type="tap", label=label, reason=f"Trying untried alternative '{label}' on this screen before backtracking", source="deterministic")

    return None


def decide(screen_state: ScreenState, goal_summary: str, history: list, state=None, precomputed_action: Action = None) -> Action:
    # Every decision in this vision version comes from evaluate_and_decide
    # (passed in as precomputed_action); scroll is only a safe fallback.
    action = precomputed_action or Action(type="scroll_down", reason="No action available", source="deterministic")
    action = enforce_prerequisites(action, screen_state, state)

    if state is not None:
        action = avoid_redoing_completed_milestone(action, screen_state, state)
        action = avoid_known_dead_ends(action, screen_state, state)
        action = avoid_reentering_unhelpful_destination(action, screen_state, state)

    if action.type == "tap" and state is not None:
        group_result = _detect_selection_group(screen_state)
        if group_result:
            group_hint, stable_key = group_result
            existing = state.get_existing_selection(stable_key, group_hint)
            chosen_label = action.label or ""

            if existing and existing != chosen_label:
                cta_element = None
                for el in screen_state.elements:
                    if not el.enabled:
                        continue
                    label = el.label.strip().lower()
                    if any(kw in label for kw in ["continue", "confirm", "proceed", "book", "done"]):
                        cta_element = el
                        break
                if cta_element:
                    action = Action(
                        type="tap",
                        label=cta_element.label,
                        reason=f"Selection guard: '{existing}' was already chosen in this group — progressing via enabled CTA instead of re-selecting",
                        source="deterministic",
                    )
                else:
                    state.record_selection(stable_key, group_hint, chosen_label)
            else:
                state.record_selection(stable_key, group_hint, chosen_label)

    if state is not None:
        action = avoid_already_failed_actions(action, screen_state, state)
        action = enforce_regression_justification(action, screen_state, state)

    return action
