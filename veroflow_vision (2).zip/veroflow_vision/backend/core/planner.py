from core.llm_controller import decompose_goal_into_milestones, check_milestone_reached
from core.schemas import ScreenState


def build_milestones(goal_summary: str) -> list:
    """
    One-time call at the start of a run: breaks the goal into an ordered
    list of milestone strings. Falls back to a single milestone (the
    whole goal) if decomposition fails, so the run degrades gracefully
    instead of crashing.
    """
    try:
        result = decompose_goal_into_milestones(goal_summary)
        milestones = result.get("milestones", [])
        if milestones:
            return milestones
    except Exception:
        pass
    return [goal_summary]


def is_milestone_reached(screen_state: ScreenState, current_milestone: str, goal_summary: str) -> dict:
    elements = [
        {
            "label": el.label, "x": el.x, "y": el.y,
            "element_type": el.element_type, "checked": el.checked, "enabled": el.enabled,
        }
        for el in screen_state.elements
    ]
    return check_milestone_reached(screen_state.screenshot_path, elements, current_milestone, goal_summary)
