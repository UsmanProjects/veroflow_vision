import os
import json
import time
import datetime

from dotenv import load_dotenv
from google import genai
from google.genai import types, errors

load_dotenv()

# ---------------------------------------------------------------------------
# Multi-key setup
# ---------------------------------------------------------------------------
# Put GEMINI_API_KEY_1 ... GEMINI_API_KEY_10 in .env. Missing ones are skipped.
# IMPORTANT: free-tier quota is per Google Cloud PROJECT, not per key. Keys
# created inside the same project share one quota, so each key must come from
# a different project (ideally a different Google account).
GEMINI_API_KEYS = [
    k for k in (os.getenv(f"GEMINI_API_KEY_{i}") for i in range(1, 11)) if k
]
if not GEMINI_API_KEYS:
    raise RuntimeError("No Gemini API keys found. Set GEMINI_API_KEY_1 (and optionally _2, _3 ...) in .env")

MODEL_NAME = "gemini-3.5-flash"

_MINUTE_COOLDOWN = 65            # seconds a key rests after a per-minute 429
_DAILY_COOLDOWN = 24 * 60 * 60   # seconds a key rests after a per-day 429
_MAX_WAIT_SECONDS = 90           # if every key is cooling longer than this, give up instead of sleeping

_clients: dict = {}
_cooldown_until: dict = {}       # key index -> epoch seconds when it may be used again
_current_key_index = 0


class AllKeysExhausted(RuntimeError):
    """Raised when every configured Gemini key has hit its limit."""


def _get_client(index: int):
    if index not in _clients:
        _clients[index] = genai.Client(api_key=GEMINI_API_KEYS[index])
    return _clients[index]


def _pick_key() -> int:
    """Return the index of a usable key. Stays on the current key until it
    is rate-limited, then moves to the next one that is not cooling down.
    If all keys are cooling down briefly, waits; if all are done for the
    day, raises AllKeysExhausted."""
    global _current_key_index
    n = len(GEMINI_API_KEYS)
    now = time.time()

    for offset in range(n):
        i = (_current_key_index + offset) % n
        if _cooldown_until.get(i, 0) <= now:
            _current_key_index = i
            return i

    wait = min(_cooldown_until.values()) - now
    if wait > _MAX_WAIT_SECONDS:
        raise AllKeysExhausted(
            f"All {n} Gemini API keys have hit their limit. "
            f"Earliest key is usable again in ~{int(wait // 60)} minutes."
        )
    print(f"[gemini] all keys cooling down, waiting {wait + 1:.0f}s")
    time.sleep(wait + 1)
    return _pick_key()


def _mark_exhausted(index: int, seconds: float):
    _cooldown_until[index] = time.time() + seconds
    print(f"[gemini] key #{index + 1} rate-limited, resting {int(seconds)}s -> switching key")


class _ResponseWrapper:
    def __init__(self, text):
        self.text = text


def _generate(contents: list, max_attempts: int = None) -> _ResponseWrapper:
    """Single entry point for every Gemini call. Handles key rotation,
    per-minute vs per-day limits, and transient server errors."""
    max_attempts = max_attempts or (len(GEMINI_API_KEYS) * 3 + 3)
    config = types.GenerateContentConfig(response_mime_type="application/json")
    last_error = None

    for _ in range(max_attempts):
        idx = _pick_key()
        try:
            response = _get_client(idx).models.generate_content(
                model=MODEL_NAME,
                contents=contents,
                config=config,
            )
            return _ResponseWrapper(response.text)

        except errors.ClientError as e:
            last_error = e
            message = str(e).lower()
            code = getattr(e, "code", None)
            if code == 429:
                cooldown = _DAILY_COOLDOWN if "perday" in message else _MINUTE_COOLDOWN
                _mark_exhausted(idx, cooldown)
                continue
            if code in (401, 403):
                # bad / disabled key: park it for the rest of the day
                _mark_exhausted(idx, _DAILY_COOLDOWN)
                continue
            raise

        except errors.ServerError as e:
            last_error = e
            time.sleep(5)
            continue

        except Exception as e:
            last_error = e
            time.sleep(5)
            continue

    raise last_error if last_error else RuntimeError("Gemini call failed")


def call_text_with_retry(prompt: str, max_retries: int = 3):
    return _generate([prompt])


def call_vision_with_retry(prompt: str, image_paths: list, max_retries: int = 3):
    """
    image_paths: list of one or two screenshot paths (two only for
    before/after outcome comparison).
    """
    contents = [prompt]
    for path in image_paths:
        with open(path, "rb") as f:
            contents.append(types.Part.from_bytes(data=f.read(), mime_type="image/png"))
    return _generate(contents)


def _current_date_context() -> str:
    today = datetime.date.today()
    next_week_start = today + datetime.timedelta(days=(7 - today.weekday()))
    next_week_end = next_week_start + datetime.timedelta(days=6)
    return (
        f"Today's real date is {today.isoformat()} ({today.strftime('%A')}). "
        f"\"Next week\" means the date range {next_week_start.isoformat()} to "
        f"{next_week_end.isoformat()}. Use this to judge whether a date shown "
        f"on screen actually satisfies a relative-date requirement in the goal "
        f"— do not guess."
    )


def _safe_json(response, fallback: dict) -> dict:
    """Shared defensive parsing used by EVERY function below."""
    if not response or not response.text:
        return fallback
    text = response.text.strip().replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        fallback = dict(fallback)
        fallback["_parse_error"] = text[:200]
        return fallback


# ---------------------------------------------------------------------------
# Pure text calls (no image needed)
# ---------------------------------------------------------------------------

def understand_goal(description: str) -> dict:
    prompt = f"""A user wants to test a mobile app feature. Their description is:

"{description}"

Summarize the user's intent in your own words: what should be accomplished in this app.
Do NOT describe what the final screen will look like. That will be judged later by looking
at the real screen — you only need to capture WHAT the user wants done.

Respond with ONLY valid JSON, no markdown, in this exact format:
{{"goal_summary": "short description of what needs to be done"}}
"""
    response = call_text_with_retry(prompt)
    return _safe_json(response, {"goal_summary": description})


def decompose_goal_into_milestones(goal_summary: str) -> dict:
    prompt = f"""Break this testing goal into an ordered sequence of high-level milestones —
the major stages a person would go through to accomplish it in ANY mobile app.

{_current_date_context()}

Goal: "{goal_summary}"

Rules:
- 3 to 8 milestones, ordered from first to last.
- Each milestone should be a general STAGE, NOT a specific screen name or button label.
- Do not assume specific navigation paths.

Respond with ONLY valid JSON, no markdown, in this exact format:
{{"milestones": ["stage 1", "stage 2", "stage 3", ...]}}
"""
    response = call_text_with_retry(prompt)
    return _safe_json(response, {"milestones": []})


# ---------------------------------------------------------------------------
# Vision calls — every one of these sends the actual screenshot(s)
# ---------------------------------------------------------------------------

def perceive_screen(screenshot_path: str) -> dict:
    from PIL import Image
    with Image.open(screenshot_path) as img:
        width, height = img.size

    prompt = f"""This is a screenshot of an Android app screen, exactly {width}x{height} pixels.

List every visible interactive element (buttons, tabs, checkboxes, toggles, input fields,
icons, links, list items). For each one, estimate its center point as x,y pixel coordinates
within this exact {width}x{height} image.

Also give ONE short sentence describing what this screen is/shows overall.

Respond with ONLY valid JSON, no markdown, in this exact format:
{{
  "screen_description": "one short sentence describing this screen",
  "elements": [
    {{"label": "exact visible text or a short description of an icon", "x": 123, "y": 456,
      "element_type": "button", "checked": null, "enabled": true}}
  ]
}}
"checked" should be true/false only for checkboxes/toggles/radio-style elements where you can
visually tell the state; use null otherwise. "enabled" should be false if the element looks
greyed out/disabled.
"""
    response = call_vision_with_retry(prompt, [screenshot_path])
    return _safe_json(response, {"screen_description": "", "elements": []})


def evaluate_and_decide(screenshot_path: str, elements: list, current_milestone: str,
                         goal_summary: str, history: list, known_unproductive: list = None) -> dict:
    elements_summary = json.dumps(elements, indent=None)
    history_summary = json.dumps(history[-3:], indent=None) if history else "None yet"

    unproductive_note = ""
    if known_unproductive:
        unproductive_note = (
            f"\nOptions already tried on THIS exact screen that did NOT work — "
            f"do NOT propose any of these again for next_action: "
            f"{json.dumps(known_unproductive, indent=None)}\n"
        )

    prompt = f"""You are controlling an Android app via its screenshot to accomplish a testing goal.

{_current_date_context()}

Overall goal: {goal_summary}
Current milestone (the stage we are actively working on right now): {current_milestone}

Recent action history (most recent last): {history_summary}
{unproductive_note}
Elements already detected on this exact screen (label, x, y, element_type, checked, enabled):
{elements_summary}

STEP 1 — Has the CURRENT MILESTONE already been accomplished, based ONLY on what is actually
visible in the screenshot right now? You MUST cite evidence as either:
- "text": the EXACT label of an element from the list above that proves it, OR
- "selection": the EXACT label of an element from the list above whose "checked" field is
  true, when the milestone is satisfied by a selection rather than new text.
Do not invent evidence that isn't a literal label from the list above.

STEP 2 — Regardless of your answer above, decide the SINGLE next action.
CRITICAL: you may ONLY reference an element by copying its "label" EXACTLY as it appears in
the list above. Never invent a label. If nothing in the list helps, choose scroll_down/scroll_up
to look for more content, or "done" if the goal is fully accomplished.

Action types:
- "tap": Requires "label" (copied exactly from the list above).
- "type": Requires "label" (of the input field) and "value" (text to type).
- "set_checkbox": Requires "label" and "checked" (true/false) — for a checkbox/toggle/radio element.
- "scroll_down" / "scroll_up": no extra fields.
- "long_press": Requires "label".
- "wait": Requires "value" (seconds).
- "done": the goal has been fully accomplished.

Respond with ONLY valid JSON, no markdown, in this exact format:
{{
  "milestone_reached": true,
  "milestone_reason": "short explanation",
  "milestone_evidence": [{{"type": "text", "value": "exact label from the list above"}}],
  "next_action": {{"action": "tap", "label": "exact label from the list above", "reason": "short reason"}}
}}
(use an empty list for milestone_evidence if milestone_reached is false)
"""
    response = call_vision_with_retry(prompt, [screenshot_path])
    fallback = {
        "milestone_reached": False,
        "milestone_reason": "LLM returned empty/unparseable response",
        "milestone_evidence": [],
        "next_action": {"action": "wait", "value": 2, "reason": "LLM returned empty response, waiting before retry"},
    }
    result = _safe_json(response, fallback)
    result.setdefault("next_action", fallback["next_action"])
    result.setdefault("milestone_evidence", [])
    return result


def check_milestone_reached(screenshot_path: str, elements: list, current_milestone: str, goal_summary: str) -> dict:
    elements_summary = json.dumps(elements, indent=None)
    prompt = f"""{_current_date_context()}

Overall goal: {goal_summary}
Current milestone: {current_milestone}

Elements detected on this screen (label, x, y, element_type, checked, enabled):
{elements_summary}

Based ONLY on what is visible, has THIS SPECIFIC MILESTONE been reached? Cite evidence as
either "text" (an exact label from the list proving it) or "selection" (an exact label whose
"checked" field is true). Do not invent evidence not in the list above.

Respond with ONLY valid JSON, no markdown, in this exact format:
{{"reached": true, "reason": "short explanation", "evidence": [{{"type": "text", "value": "exact label"}}]}}
or
{{"reached": false, "reason": "short explanation", "evidence": []}}
"""
    response = call_vision_with_retry(prompt, [screenshot_path])
    return _safe_json(response, {"reached": False, "reason": "LLM returned empty response", "evidence": []})


def check_success(screenshot_path: str, elements: list, goal_summary: str) -> dict:
    elements_summary = json.dumps(elements, indent=None)
    prompt = f"""You are checking if a testing goal has already been accomplished.

Goal: {goal_summary}

Elements detected on the current screen (label, x, y, element_type, checked, enabled):
{elements_summary}

Based ONLY on what is visible right now, has the goal been accomplished? Cite an exact label
from the list above as evidence. If you cannot, answer false.

Respond with ONLY valid JSON, no markdown, in this exact format:
{{"success": true, "reason": "short explanation", "evidence_text": "exact label from the list"}}
or
{{"success": false, "reason": "short explanation of what's missing", "evidence_text": ""}}
"""
    response = call_vision_with_retry(prompt, [screenshot_path])
    return _safe_json(response, {"success": False, "reason": "LLM returned empty response", "evidence_text": ""})


def validate_generic_outcome(before_path: str, before_elements: list, after_path: str,
                              after_elements: list, goal_summary: str) -> dict:
    before_labels = {el.get("label", "").strip().lower() for el in before_elements}
    prompt = f"""A user tested this goal: "{goal_summary}"

The FIRST image is the screen BEFORE the final action. The SECOND image is the screen AFTER it.

Elements detected in the BEFORE screen: {json.dumps(before_elements, indent=None)}
Elements detected in the AFTER screen: {json.dumps(after_elements, indent=None)}

Compare the two. Did this test PASS or FAIL?

CRITICAL RULES:
- Cite evidence as an exact label from the AFTER elements list that proves completion.
- The evidence label must NOT also appear in the BEFORE elements list — if the same label was
  already visible before the final action, it is NOT proof of something new happening; it's
  just pre-existing screen content. Pick a genuinely new label, or answer fail.
- If the AFTER screen shows an error, validation warning, or looks the same as BEFORE with
  no meaningful new element, the result MUST be "fail".

Respond with ONLY valid JSON, no markdown, in this exact format:
{{"result": "pass", "reason": "short explanation", "evidence_text": "exact NEW label from AFTER"}}
or
{{"result": "fail", "reason": "short explanation", "evidence_text": ""}}
"""
    response = call_vision_with_retry(prompt, [before_path, after_path])
    result = _safe_json(response, {"result": "fail", "reason": "LLM returned empty response", "evidence_text": ""})

    if result.get("result") == "pass":
        evidence = (result.get("evidence_text") or "").strip().lower()
        if not evidence or evidence in before_labels:
            return {
                "result": "fail",
                "reason": f"Claimed success citing '{evidence}', but this was already present BEFORE the final action — not new evidence.",
                "evidence_text": "",
            }
    return result


def generate_form_fill(screenshot_path: str, elements: list, goal_summary: str) -> dict:
    input_like = [el for el in elements if el.get("element_type") == "input"]
    prompt = f"""You are filling out a form to accomplish this goal: "{goal_summary}"

Detected input fields on this screen: {json.dumps(input_like, indent=None)}
All detected elements on this screen: {json.dumps(elements, indent=None)}

For each input field, decide a realistic value to type (dummy/test data is fine if the goal
doesn't specify real values). Identify the button that submits/confirms this form.

Respond with ONLY valid JSON, no markdown, in this exact format:
{{"field_values": {{"exact-label-1": "value1", "exact-label-2": "value2"}}, "submit_label": "exact label of the submit button, or empty string"}}
"""
    response = call_vision_with_retry(prompt, [screenshot_path])
    return _safe_json(response, {"field_values": {}, "submit_label": ""})