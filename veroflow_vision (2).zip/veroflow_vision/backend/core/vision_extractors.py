"""
Vision equivalents of the XML version's CounterExtractor/CalendarExtractor/
CheckboxExtractor + resolve_state engine.

IMPORTANT HONEST NOTE: the XML version's extractors were reliable because
they read exact boolean/numeric attributes (checked="true", a literal
digit in a text node) straight from the accessibility tree. There is no
equivalent ground truth in a screenshot — every "read" here is the vision
model's own visual judgment, which can be wrong in ways the XML version
structurally could not be. Treat this file as best-effort, not as reliable
as what it replaces. CalendarExtractor's deterministic day-tap logic has
NO vision equivalent at all (it depended entirely on an XML content-desc
naming convention with no visual analog) — calendar/date-range selection
in this version is handled as ordinary label-based taps chosen by the
per-step decision loop instead, which is less deterministic.
"""

import time
import math
from core.schemas import ScreenState


def _find_by_label(screen_state: ScreenState, label: str):
    """Exact match first, then loose substring match, since vision-read
    text may not be pixel-perfect verbatim across two separate calls."""
    label_lower = label.strip().lower()
    for el in screen_state.elements:
        if el.label.strip().lower() == label_lower:
            return el
    best, best_score = None, 0
    for el in screen_state.elements:
        el_lower = el.label.strip().lower()
        if not el_lower:
            continue
        if label_lower in el_lower or el_lower in label_lower:
            score = min(len(label_lower), len(el_lower)) / max(len(label_lower), len(el_lower))
            if score > best_score:
                best, best_score = el, score
    return best if best_score >= 0.5 else None


def resolve_checkbox(screen_state: ScreenState, label: str, target_value: bool,
                      tap_function, redump_function, build_screen_state_function,
                      verify_delay: float = 1.0) -> dict:
    """
    Generic engine step for a checkbox/toggle: find it by label, check its
    current (vision-judged) checked state, tap once if it needs to change,
    re-perceive to verify. Mirrors the XML version's resolve_state()
    contract (always returns a dict, never raises) so orchestrator.py's
    dispatch logic can stay structurally similar.
    """
    element = _find_by_label(screen_state, label)
    if element is None:
        return {"matched": False, "error": f"Could not find checkbox/toggle labeled '{label}'"}

    current_checked = bool(element.checked)
    if current_checked == target_value:
        return {"matched": True, "already_satisfied": True, "current_value": current_checked}

    tap_function(element.x, element.y)
    time.sleep(verify_delay)

    fresh_state = build_screen_state_function(redump_function())
    fresh_element = _find_by_label(fresh_state, label)
    final_checked = bool(fresh_element.checked) if fresh_element else None
    verified = (final_checked == target_value)

    return {
        "matched": True,
        "already_satisfied": False,
        "from_value": current_checked,
        "target_value": target_value,
        "final_value": final_checked,
        "verified": verified,
    }


def resolve_counter(screen_state: ScreenState, label: str, target_value: int,
                     tap_function, redump_function, build_screen_state_function,
                     verify_delay: float = 1.0) -> dict:
    """
    Best-effort counter handling. Looks for "Increase {label}"/"Decrease
    {label}"-style elements (or generic "+"/"-" elements near a bare
    numeric element) to find the current value and the tap targets.
    Unlike the XML version, there is no guaranteed content-desc
    convention to rely on — this only works if perceive_screen happened
    to label things this way, which depends on the app's own visual
    design being unambiguous. Falls back to a clear failure if it can't
    confidently identify all three parts (current value, +, -).
    """
    increase_el = _find_by_label(screen_state, f"Increase {label}") or _find_by_label(screen_state, "+")
    decrease_el = _find_by_label(screen_state, f"Decrease {label}") or _find_by_label(screen_state, "-")

    current_value = None
    if increase_el and decrease_el:
        mid_x = (increase_el.x + decrease_el.x) / 2
        mid_y = (increase_el.y + decrease_el.y) / 2
        best, best_dist = None, None
        for el in screen_state.elements:
            if el.label.strip().isdigit():
                dist = math.hypot(el.x - mid_x, el.y - mid_y)
                if best_dist is None or dist < best_dist:
                    best, best_dist = el, dist
        if best is not None:
            current_value = int(best.label.strip())

    if current_value is None or increase_el is None or decrease_el is None:
        return {"matched": False, "error": f"Could not confidently identify counter parts for '{label}'"}

    delta = target_value - current_value
    if delta == 0:
        return {"matched": True, "already_satisfied": True, "current_value": current_value}

    target_el = increase_el if delta > 0 else decrease_el
    for _ in range(abs(delta)):
        tap_function(target_el.x, target_el.y)
        time.sleep(verify_delay)

    fresh_state = build_screen_state_function(redump_function())
    increase_el2 = _find_by_label(fresh_state, f"Increase {label}") or _find_by_label(fresh_state, "+")
    decrease_el2 = _find_by_label(fresh_state, f"Decrease {label}") or _find_by_label(fresh_state, "-")
    final_value = None
    if increase_el2 and decrease_el2:
        mid_x = (increase_el2.x + decrease_el2.x) / 2
        mid_y = (increase_el2.y + decrease_el2.y) / 2
        best, best_dist = None, None
        for el in fresh_state.elements:
            if el.label.strip().isdigit():
                dist = math.hypot(el.x - mid_x, el.y - mid_y)
                if best_dist is None or dist < best_dist:
                    best, best_dist = el, dist
        if best is not None:
            final_value = int(best.label.strip())

    return {
        "matched": True,
        "already_satisfied": False,
        "from_value": current_value,
        "target_value": target_value,
        "final_value": final_value,
        "verified": final_value == target_value,
    }
