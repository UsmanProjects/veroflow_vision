from core.schemas import Action, ScreenState
from core.adb_controller import (
    tap, type_text, clear_field, swipe, scroll_down, scroll_up, long_press,
)


class ExecutionResult:
    def __init__(self, success: bool, error: str = None):
        self.success = success
        self.error = error


def _resolve_coords(action: Action, screen_state: ScreenState):
    """Resolve an action's target to (x, y): direct coordinates win if
    given, otherwise look the label up in the already-perceived elements."""
    if action.x1 is not None and action.y1 is not None:
        return (action.x1, action.y1)
    if action.label:
        label_lower = action.label.strip().lower()
        for el in screen_state.elements:
            if el.label.strip().lower() == label_lower:
                return (el.x, el.y)
    return None


def execute_action(action: Action, screen_state: ScreenState) -> ExecutionResult:
    """
    The only place in the system that calls ADB to perform an action —
    same role as the XML version's action_executor. set_checkbox/
    set_counter are NOT handled here; those go through vision_extractors
    via orchestrator's own dispatch, exactly like the XML version's
    widget dispatch split.
    """
    try:
        if action.type == "tap":
            coords = _resolve_coords(action, screen_state)
            if coords is None:
                return ExecutionResult(False, f"Could not resolve coordinates for label '{action.label}'")
            tap(coords[0], coords[1])
            return ExecutionResult(True)

        elif action.type == "type":
            coords = _resolve_coords(action, screen_state)
            if coords is None:
                return ExecutionResult(False, f"Could not resolve coordinates for label '{action.label}'")
            clear_field(coords[0], coords[1])
            type_text(action.value or "")
            return ExecutionResult(True)

        elif action.type == "scroll_down":
            scroll_down()
            return ExecutionResult(True)

        elif action.type == "scroll_up":
            scroll_up()
            return ExecutionResult(True)

        elif action.type == "long_press":
            coords = _resolve_coords(action, screen_state)
            if coords is None:
                return ExecutionResult(False, f"Could not resolve coordinates for label '{action.label}'")
            long_press(coords[0], coords[1])
            return ExecutionResult(True)

        elif action.type == "swipe":
            swipe(action.x1, action.y1, action.x2, action.y2)
            return ExecutionResult(True)

        elif action.type == "wait":
            return ExecutionResult(True)  # orchestrator handles the actual sleep

        else:
            return ExecutionResult(False, f"Unknown action type: {action.type}")

    except Exception as e:
        return ExecutionResult(False, f"Execution error: {str(e)}")
