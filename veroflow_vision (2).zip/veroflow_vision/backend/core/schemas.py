from dataclasses import dataclass
from typing import Optional, Any


@dataclass
class VisualElement:
    """
    A candidate interactive element as the vision model reports it from
    a screenshot. Unlike the old XML-based Element, every field here is
    the model's own visual judgment, not a ground-truth XML attribute —
    there is no accessibility tree backing this up. Treat 'checked' and
    'enabled' as best-effort visual estimates, not guaranteed-accurate
    state.
    """
    label: str                      # what the model read/saw for this element (button text, icon description, etc.)
    x: int                          # approximate center x coordinate, in the screenshot's own pixel space
    y: int                          # approximate center y coordinate
    element_type: str = "button"    # model's guess: button / checkbox / toggle / input / tab / link / icon / text
    checked: Optional[bool] = None  # model's visual judgment, only meaningful if element_type suggests a toggle/checkbox/radio
    enabled: bool = True            # model's visual judgment (greyed out vs not)


@dataclass
class ScreenState:
    screenshot_path: str
    screen_width: int
    screen_height: int
    elements: list                   # list[VisualElement] — the model's own enumeration, not ground truth
    screen_description: str = ""     # short model-generated summary; used to build screen_signature and for stability checks


@dataclass
class Action:
    type: str                        # "tap" | "type" | "scroll_down" | "scroll_up" | "long_press" | "swipe" | "set_checkbox" | "wait" | "done"
    x1: Optional[int] = None
    y1: Optional[int] = None
    x2: Optional[int] = None
    y2: Optional[int] = None
    label: Optional[str] = None      # the element's label, when targeting by label rather than raw coordinates
    value: Optional[str] = None      # text to type, or wait seconds (as string)
    target_value: Any = None         # for set_checkbox: True/False
    reason: str = ""
    source: str = "llm"              # "deterministic" | "llm"
    failure_reason: Optional[str] = None  # "current_option_unavailable" | "required_element_disabled" | "dead_end_no_new_options" | None


@dataclass
class VerificationResult:
    success: bool
    reason: str
    checked_against: str = "current_screen"   # "current_screen" | "before_after_diff"


@dataclass
class StepEvent:
    step_number: int
    screen_before: Optional[ScreenState]
    action_taken: Optional[Action]
    verification: Optional[VerificationResult]
    error: Optional[str] = None
    blocked_duplicate: bool = False
    widget_result: Optional[dict] = None
    milestone_debug: Optional[dict] = None
