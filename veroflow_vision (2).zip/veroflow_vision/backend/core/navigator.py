from core.schemas import Action


def build_action_from_raw(raw_decision: dict) -> Action:
    """Converts evaluate_and_decide's raw {"action": ...} dict into a
    structured Action. Action types here are label/coordinate based
    (tap/type/set_checkbox/scroll/long_press/swipe/wait/done) rather
    than the XML version's resource_id-based vocabulary."""
    target_value = None
    if "checked" in raw_decision:
        target_value = raw_decision["checked"]

    return Action(
        type=raw_decision.get("action", "wait"),
        label=raw_decision.get("label"),
        value=raw_decision.get("value"),
        x1=raw_decision.get("x1"),
        y1=raw_decision.get("y1"),
        x2=raw_decision.get("x2"),
        y2=raw_decision.get("y2"),
        target_value=target_value,
        reason=raw_decision.get("reason", ""),
        source="llm",
    )
