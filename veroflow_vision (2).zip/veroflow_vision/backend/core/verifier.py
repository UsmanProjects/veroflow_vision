from core.schemas import ScreenState, VerificationResult
from core.llm_controller import check_success, validate_generic_outcome


def _elements_as_dicts(screen_state: ScreenState) -> list:
    return [
        {
            "label": el.label,
            "x": el.x,
            "y": el.y,
            "element_type": el.element_type,
            "checked": el.checked,
            "enabled": el.enabled,
        }
        for el in screen_state.elements
    ]


def try_deterministic_check(before: ScreenState, after: ScreenState) -> VerificationResult | None:
    """
    Cheap, no-LLM check: if the set of detected (label, type) pairs is
    identical before and after, nothing changed — a confident "not yet
    successful" without spending a vision call. Only ever returns a
    confident NO; never claims success on its own.
    """
    before_sig = {(el.label.strip().lower(), el.element_type) for el in before.elements}
    after_sig = {(el.label.strip().lower(), el.element_type) for el in after.elements}

    if before_sig == after_sig:
        return VerificationResult(
            success=False,
            reason="Deterministic: no change detected between before/after screen state",
            checked_against="before_after_diff",
        )
    return None


def verify_now(screen_state: ScreenState, goal_summary: str) -> VerificationResult:
    """Mid-flow check: has the goal ALREADY been accomplished on the CURRENT screen?"""
    result = check_success(screen_state.screenshot_path, _elements_as_dicts(screen_state), goal_summary)
    claimed_success = result.get("success", False)
    evidence_text = (result.get("evidence_text") or "").strip().lower()

    if claimed_success:
        labels = {el.label.strip().lower() for el in screen_state.elements}
        if not evidence_text or evidence_text not in labels:
            return VerificationResult(
                success=False,
                reason=f"Model claimed success citing '{evidence_text}', but that label was not among the elements actually detected on this screen — treating as unverified.",
                checked_against="current_screen",
            )

    return VerificationResult(
        success=claimed_success,
        reason=result.get("reason", ""),
        checked_against="current_screen",
    )


def verify_final(before: ScreenState, after: ScreenState, goal_summary: str) -> VerificationResult:
    """
    `before` MUST be the screen state immediately preceding the FINAL
    action taken, NOT the very first screen of the whole run. (Using the
    run's first screen as the reference was a confirmed bug in the XML
    version — almost any later-screen text looks "new" relative to
    onboarding even when it's just pre-existing content.)
    """
    deterministic = try_deterministic_check(before, after)
    if deterministic is not None:
        return deterministic

    result = validate_generic_outcome(
        before.screenshot_path, _elements_as_dicts(before),
        after.screenshot_path, _elements_as_dicts(after),
        goal_summary,
    )
    claimed_pass = result.get("result") == "pass"
    evidence_text = (result.get("evidence_text") or "").strip().lower()

    if claimed_pass:
        after_labels = {el.label.strip().lower() for el in after.elements}
        if not evidence_text or evidence_text not in after_labels:
            return VerificationResult(
                success=False,
                reason=f"Model claimed success citing '{evidence_text}', but that label was not among the elements actually detected on the after-screen — treating as unverified/fail.",
                checked_against="before_after_diff",
            )

    return VerificationResult(
        success=claimed_pass,
        reason=result.get("reason", ""),
        checked_against="before_after_diff",
    )
