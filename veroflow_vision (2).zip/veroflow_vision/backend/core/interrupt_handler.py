from core.schemas import ScreenState, Action
from core.perception import detect_interrupt

# Keyword -> safe default recovery label. Same list as the XML version.
SAFE_RECOVERY_MAP = {
    "while using the app": "While using the app",
    "only this time": "Only this time",
    "allow": "Allow",
    "deny": "Deny",
    "not now": "Not now",
    "no thanks": "No thanks",
    "update available": "Later",
    "keep app open": "Keep app open",
    "close app": "Close app",
}


def resolve_interrupt(screen_state: ScreenState) -> tuple[bool, Action | None]:
    """
    Returns (is_interrupt, action):
      (False, None)  -> not an interrupt, proceed normally
      (True, Action) -> interrupt found, safe recovery action ready
      (True, None)   -> interrupt found, but no deterministic match
    """
    if not detect_interrupt(screen_state):
        return False, None

    for element in screen_state.elements:
        label = element.label.strip().lower()
        for keyword in SAFE_RECOVERY_MAP:
            if keyword in label:
                return True, Action(
                    type="tap",
                    label=element.label,
                    reason=f"Deterministic interrupt recovery: matched '{keyword}'",
                    source="deterministic",
                )

    return True, None
