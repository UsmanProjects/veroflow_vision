from core.schemas import StepEvent


class TestRunState:
    """
    Single source of truth for one test run's progress. Ported from the
    final, most-refined state of the XML version (after RC1-RC9 and the
    evidence-reuse-adjacent-milestone fix), adapted so every action-identity
    key uses `label` instead of resource_id/text.
    """

    def __init__(self, goal_summary: str, max_steps: int = 20):
        self.goal_summary = goal_summary
        self.max_steps = max_steps
        self.current_step = 0
        self.events: list[StepEvent] = []
        self.performed_core_actions: set = set()
        self.completed_widgets: set = set()
        self.finished = False
        self.recent_screen_signatures: list = []
        self.dead_end_paths: set = set()
        self.last_screen_before_action = None
        self.milestones: list = []
        self.current_milestone_index: int = 0
        self.milestone_dead_end_counts: dict = {}
        self.selection_groups: dict = {}
        self.last_milestone_debug = None
        self.used_milestone_evidence: dict = {}  # evidence_key -> milestone_index it was first used for
        self.milestone_check_failures: dict = {}
        self.milestone_screens_seen: dict = {}
        self.screen_depth: dict = {}
        self.max_depth_reached: int = 0
        self.action_outcomes: dict = {}
        self.milestone_check_cache: dict = {}
        self.verification_cache: dict = {}
        self.completed_milestone_screens: set = set()
        self.action_destinations: dict = {}  # (origin_sig, label_lower) -> destination_sig

    def record_event(self, event: StepEvent):
        self.events.append(event)
        self.current_step += 1

    def recent_actions(self, lookback: int = 3):
        return self.events[-lookback:]

    def is_repeating(self, lookback: int = 3) -> bool:
        if len(self.events) < 2:
            return False
        recent = self.recent_actions(lookback)
        sigs = []
        for e in recent:
            a = e.action_taken
            if a is None:
                continue
            sigs.append(f"{a.type}-{a.label}-{a.value}-{a.x1}-{a.y1}")
        return len(set(sigs)) == 1 and len(sigs) >= 2

    def mark_core_action(self, identifier: str):
        self.performed_core_actions.add(identifier)

    def is_core_action_done(self, identifier: str) -> bool:
        return identifier in self.performed_core_actions

    def mark_widget_complete(self, widget_type: str, label: str = ""):
        self.completed_widgets.add(f"{widget_type}:{label}")

    def is_widget_complete(self, widget_type: str, label: str = "") -> bool:
        return f"{widget_type}:{label}" in self.completed_widgets

    def budget_exceeded(self) -> bool:
        return self.current_step >= self.max_steps

    def record_screen_signature(self, sig: str, lookback: int = 4):
        self.recent_screen_signatures.append(sig)
        if len(self.recent_screen_signatures) > lookback:
            self.recent_screen_signatures.pop(0)

    def screen_signature_is_static(self, lookback: int = 3) -> bool:
        if len(self.recent_screen_signatures) < lookback:
            return False
        recent = self.recent_screen_signatures[-lookback:]
        return len(set(recent)) == 1

    def mark_dead_end(self, origin_signature: str, label: str):
        self.dead_end_paths.add((origin_signature, label.strip().lower()))

    def is_known_dead_end(self, origin_signature: str, label: str) -> bool:
        return (origin_signature, label.strip().lower()) in self.dead_end_paths

    def set_milestones(self, milestones: list):
        self.milestones = milestones
        self.current_milestone_index = 0

    def current_milestone(self) -> str:
        if not self.milestones:
            return self.goal_summary
        idx = min(self.current_milestone_index, len(self.milestones) - 1)
        return self.milestones[idx]

    def advance_milestone(self):
        if self.current_milestone_index < len(self.milestones) - 1:
            self.current_milestone_index += 1

    def record_milestone_dead_end(self):
        idx = self.current_milestone_index
        self.milestone_dead_end_counts[idx] = self.milestone_dead_end_counts.get(idx, 0) + 1

    def milestone_exhausted(self, threshold: int = 4) -> bool:
        idx = self.current_milestone_index
        return self.milestone_dead_end_counts.get(idx, 0) >= threshold

    def record_selection(self, screen_sig: str, group_hint: str, chosen_label: str):
        self.selection_groups[(screen_sig, group_hint)] = chosen_label

    def get_existing_selection(self, screen_sig: str, group_hint: str):
        return self.selection_groups.get((screen_sig, group_hint))

    def evidence_already_used(self, evidence_text: str) -> bool:
        """
        Blocks reusing the same evidence for a milestone more than one
        step removed from where it was first used. The very NEXT
        milestone in sequence is allowed to reuse it, since a single
        real action often naturally satisfies two adjacent planning
        steps at once (e.g. "search for X" and "select X" both
        happening via one tap) — blocking that was a confirmed bug in
        the XML version. Anything further away is still blocked, since
        that would be a genuinely lazy/wrong repeat.
        """
        key = evidence_text.strip().lower()
        if key not in self.used_milestone_evidence:
            return False
        used_at_index = self.used_milestone_evidence[key]
        if self.current_milestone_index == used_at_index + 1:
            return False
        return True

    def mark_evidence_used(self, evidence_text: str):
        key = evidence_text.strip().lower()
        self.used_milestone_evidence[key] = self.current_milestone_index

    def record_milestone_check_failure(self, screen_sig: str):
        idx = self.current_milestone_index
        seen = self.milestone_screens_seen.setdefault(idx, set())
        if screen_sig in seen:
            self.milestone_check_failures[idx] = self.milestone_check_failures.get(idx, 0) + 1
        else:
            seen.add(screen_sig)
            self.milestone_check_failures[idx] = 0

    def reset_milestone_check_failures(self):
        idx = self.current_milestone_index
        self.milestone_check_failures[idx] = 0
        self.milestone_screens_seen[idx] = set()

    def milestone_unreachable(self, threshold: int = 3) -> bool:
        idx = self.current_milestone_index
        return self.milestone_check_failures.get(idx, 0) >= threshold

    def get_cached_milestone_check(self, screen_sig: str):
        return self.milestone_check_cache.get((self.current_milestone_index, screen_sig))

    def cache_milestone_check(self, screen_sig: str, result: dict):
        self.milestone_check_cache[(self.current_milestone_index, screen_sig)] = result

    def get_cached_verification(self, screen_sig: str):
        return self.verification_cache.get(screen_sig)

    def cache_verification(self, screen_sig: str, result):
        self.verification_cache[screen_sig] = result

    def skip_current_milestone(self):
        self.reset_milestone_check_failures()
        self.advance_milestone()
        self.recent_screen_signatures.clear()

    def mark_current_milestone_screens_completed(self):
        seen = self.milestone_screens_seen.get(self.current_milestone_index, set())
        self.completed_milestone_screens.update(seen)

    def is_completed_milestone_screen(self, screen_sig: str) -> bool:
        return screen_sig in self.completed_milestone_screens

    def record_action_destination(self, origin_sig: str, label: str, destination_sig: str):
        self.action_destinations[(origin_sig, label.strip().lower())] = destination_sig

    def get_action_destination(self, origin_sig: str, label: str):
        return self.action_destinations.get((origin_sig, label.strip().lower()))

    def is_unhelpful_milestone_screen(self, screen_sig: str) -> bool:
        seen = self.milestone_screens_seen.get(self.current_milestone_index, set())
        return screen_sig in seen

    def _action_key(self, action) -> str:
        if action.type == "set_checkbox":
            return f"set_checkbox:{action.label}:{action.target_value}"
        return f"{action.type}:{action.label or ''}"

    def record_screen_depth(self, screen_sig: str) -> int:
        if screen_sig not in self.screen_depth:
            self.screen_depth[screen_sig] = self.max_depth_reached + 1
        depth = self.screen_depth[screen_sig]
        self.max_depth_reached = max(self.max_depth_reached, depth)
        return depth

    def current_is_regression(self, screen_sig: str) -> bool:
        depth = self.screen_depth.get(screen_sig)
        return depth is not None and depth < self.max_depth_reached

    def record_action_outcome(self, screen_sig: str, action, changed_screen: bool, error):
        key = (screen_sig, self._action_key(action))
        entry = self.action_outcomes.setdefault(key, {
            "attempts": 0, "ever_changed_screen": False, "last_error": None,
        })
        entry["attempts"] += 1
        entry["ever_changed_screen"] = entry["ever_changed_screen"] or changed_screen
        entry["last_error"] = error

    def action_already_failed(self, screen_sig: str, action) -> bool:
        key = (screen_sig, self._action_key(action))
        entry = self.action_outcomes.get(key)
        return bool(entry) and entry["attempts"] > 0 and not entry["ever_changed_screen"]

    def screen_has_recorded_failure(self, screen_sig: str) -> bool:
        return any(
            sig == screen_sig and v["attempts"] > 0 and not v["ever_changed_screen"]
            for (sig, _key), v in self.action_outcomes.items()
        )

    def known_unproductive_labels_for_screen(self, screen_sig: str) -> list:
        labels = {label for (sig, label) in self.dead_end_paths if sig == screen_sig}
        for (sig, action_key), outcome in self.action_outcomes.items():
            if sig != screen_sig:
                continue
            if outcome["attempts"] > 0 and not outcome["ever_changed_screen"]:
                parts = action_key.split(":", 1)
                if len(parts) == 2 and parts[0] in ("tap",):
                    labels.add(parts[1])
        return sorted(labels)
